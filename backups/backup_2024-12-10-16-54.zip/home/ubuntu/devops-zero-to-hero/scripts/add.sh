#!/bin/bash
echo "Addition of 2 no's"

a=3
b=7
c=add($a,$b)

echo "the addition of 2 no's is $c"
