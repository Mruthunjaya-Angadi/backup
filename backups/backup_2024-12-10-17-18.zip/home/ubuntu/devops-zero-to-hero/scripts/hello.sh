#!/bin/bash

echo "welcome to shell scripting"

echo "Hello dosto"

date

whoami
